//import util.properties packages
import java.util.Properties;

//import simple producer packages
import org.apache.kafka.clients.producer.Producer;

//import KafkaProducer packages
import org.apache.kafka.clients.producer.KafkaProducer;

//import ProducerRecord packages
import org.apache.kafka.clients.producer.ProducerRecord;



//Create java class named “SimpleProducer”
public class SimpleProducer {

    public static void main(String[] args) throws Exception{
        String topicName = args[0].toString();
        //retries e mau pode dar em duplicado acho que por default ta a 0.
        //linger.ms na esperaça de acumular masi records antes de mandar
        //buffer memory e max.block.ms
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        //blocking on the full commit of the record
        props.put("acks", "all");
        //instruct how to turn the key and value objects the user provides with their ProducerRecord into bytes
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.LongSerializer");

        Producer<String, Long> producer = new KafkaProducer<>(props);
        for(int i = 0; i < 1000; i++)
            producer.send(new ProducerRecord<String, Long>(topicName, Integer.toString(i), (long) i));

        System.out.println("Message sent successfully to topic " + topicName);
        producer.close();
    }
}