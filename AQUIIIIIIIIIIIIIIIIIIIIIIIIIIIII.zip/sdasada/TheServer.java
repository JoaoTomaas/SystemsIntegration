import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.project.grpc.ConnectionReply;
import com.project.grpc.ConnectionRequest;
import com.project.grpc.GreeterGrpc;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;


import com.project.protob.CarOwnerProtoB.Owner;
import com.project.protob.CarOwnerProtoB.OwnerList;
import com.project.protob.CarOwnerProtoB.Car;
import com.project.protob.CarOwnerProtoB.CarList;

import io.grpc.Server;


public class TheServer {

    static class GreeterImpl extends GreeterGrpc.GreeterImplBase {

        @Override
        public void greetAndConnect (ConnectionRequest request, StreamObserver<ConnectionReply> responseObserver) throws InvalidProtocolBufferException {

            //XML
            if (request.hasMsgXml()) {
                //Medição do tempo desde que recebe o pedido até enviar a resposta
                long startTime = System.nanoTime(); //Inicia o cronómetro

                XmlToObject xmltoobject=new XmlToObject("teste1.xml");
                ListaDono owners=xmltoobject.work(request.getMsgXml());


                //Tempo de encher os charutos
                long startFill = System.nanoTime(); //Inicia o cronómetro
                ListaCarro cars=listOfCarsXml(owners);
                long TimeFill = System.nanoTime() - startFill;
                System.out.println("Tempo encher XML(servidor): " + TimeFill/1000);

                ObjectToXml cenas=new ObjectToXml("teste2.xml",cars);

                long estimatedTime = System.nanoTime() - startTime;
                System.out.println("Tempo total XML(servidor): " + estimatedTime/1000);

                ConnectionReply reply=ConnectionReply.newBuilder().setRpXml(cenas.teste2()).build();
                responseObserver.onNext(reply);
                responseObserver.onCompleted();
            }
            //PROTO
            else {
                //Medição do tempo desde que recebe o pedido até enviar a resposta
                long startTime = System.nanoTime(); //Inicia o cronómetro

                //Deserialization (Protob -> Object)
                OwnerList lista_donos = OwnerList.parseFrom(request.getMsgPb());

                long estimated_desserial = System.nanoTime() - startTime;
                System.out.println("Tempo Proto (desserializa): " + estimated_desserial/1000);

                //Method that receives the list of owners and returns the list of cars per owner
                CarList retorna_carros = null;
                try {
                    //Tempo de encher os charutos
                    long startFill = System.nanoTime(); //Inicia o cronómetro

                    retorna_carros = devolve_carros(lista_donos);

                    long TimeFill = System.nanoTime() - startFill;
                    System.out.println("Tempo encher Proto(servidor): " + TimeFill/1000);

                } catch (IOException e) {
                    e.printStackTrace();
                }


                //Medição do tempo de serialização
                long startSerial = System.nanoTime();

                //Searilize the returned value of the method and send it as a reply to the client
                ByteString serial_reply = null;
                if (retorna_carros != null) {
                    serial_reply = retorna_carros.toByteString();
                }

                long estimatedSerial = System.nanoTime() - startSerial;
                System.out.println("Tempo Proto (serializa): " + estimatedSerial/1000);

                //Resposta que vai ser enviada para o cliente
                //ConnectionReply reply = ConnectionReply.newBuilder().setRpPb(request.getMsgPb()).build();
                ConnectionReply reply = ConnectionReply.newBuilder().setRpPb(serial_reply).build();
                responseObserver.onNext(reply);

                long estimatedTime = System.nanoTime() - startTime;
                System.out.println("Tempo total Protol(servidor): " + estimatedTime/1000);

                responseObserver.onCompleted();
            }
        }
    }

    private static final Logger msg = Logger.getLogger(Server.class.getName());
    private Server server;
    public static ListaCarro database;
    public static CarList database_proto;


    private void start() throws IOException {
        GetCars cenas=new GetCars("Car10.txt");

        try {
            ListaCarro teste=cenas.work();

            database_proto=cria_proto_database(teste);
            database=teste;

        } catch (IOException e) {
            e.printStackTrace();
        }

        int port = 9000; //Porto no qual o servidor deve correr
        server = ServerBuilder.forPort(port).addService(new GreeterImpl()).build().start();

        msg.info("Servidor iniciado, à escuta no porto " + port);
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                System.err.println("Shutting down gRpc server since JVM is shutting down");
                TheServer.this.stop();
                System.err.println("Server shut down");
            }
        });
    }

    private void stop() {
        if (server != null) {
            server.shutdown();
        }
    }

    private void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        final TheServer server = new TheServer();
        server.start();
        server.blockUntilShutdown();
    }


    //Method to receive the list of owners and return a list of their cars in response
    //PROTO
    public static CarList devolve_carros(OwnerList owners) throws IOException {
        //Ver se é preciso separar por owner ou se pode ser todos em conjunto
        CarList.Builder retorna_garagem = CarList.newBuilder();

        for (Owner o: owners.getOwnersList()){  //Procurar por id do owner
            for (Car c: database_proto.getCarsList()){
                if (c.getOwnerId() == o.getId()){
                    //System.out.println("Id do owner: " + o.getId() + " Id do owner do carro" + c.getOwnerId());
                    retorna_garagem.addCars(c);
                }
            }
        }

        return retorna_garagem.build();
    }

    //XML
    public static ListaCarro listOfCarsXml(ListaDono listOfOwners){
        ListaCarro devolve=new ListaCarro();
        ArrayList<Carro> aux=new ArrayList<>();
        int tamanho=listOfOwners.getOwner_list().size();
        for(Dono owner:listOfOwners.getOwner_list()){
            for(Carro carro: database.getCar_list()){
                if(carro.getOwner_id()==owner.getId()){
                    aux.add(carro);
                }

            }
        }
        devolve.setCar_list(aux);
        return devolve;
    }


    //Protocol Buffers Database
    public static CarList cria_proto_database (ListaCarro teste){

        CarList.Builder aux=CarList.newBuilder();

        for(Carro e:teste.getCar_list()){
            Car.Builder auxliar=Car.newBuilder();
            auxliar.setId(e.getId());
            auxliar.setConsumption(e.getConsumption());
            auxliar.setEngineSize(e.getEngine_size());
            auxliar.setOwnerId(e.getOwner_id());
            auxliar.setPower(e.getPower());
            auxliar.setBrand(e.getBrand());
            auxliar.setPlate(e.getPlate());
            auxliar.setModel(e.getModel());
            auxliar.build();
            aux.addCars(auxliar);
        }

        return aux.build();
    }


}
